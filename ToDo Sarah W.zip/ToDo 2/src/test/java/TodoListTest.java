import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TodoListTest {

    @Test
    void testAddTask() {
        TodoList list = new TodoList();
        list.addTask("Test Task");

        assertEquals(1, list.size());
        assertEquals("Test Task", list.getTasks().get(0));
    }
}