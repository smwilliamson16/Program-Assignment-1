import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TodoApp extends Application {

    private final TodoList todoList = new TodoList();
    private Stage primaryStage;

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        primaryStage.setTitle("To-Do List App");
        showMainMenu();
        primaryStage.show();
    }

    private void showMainMenu() {
        Label title = new Label("To-Do List App");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Button addButton = new Button("Add Task");
        Button viewButton = new Button("View Tasks");
        Button deleteButton = new Button("Delete Task");
        Button clearButton = new Button("Clear Tasks");
        Button exitButton = new Button("Exit");

        addButton.setMaxWidth(Double.MAX_VALUE);
        viewButton.setMaxWidth(Double.MAX_VALUE);
        deleteButton.setMaxWidth(Double.MAX_VALUE);
        clearButton.setMaxWidth(Double.MAX_VALUE);
        exitButton.setMaxWidth(Double.MAX_VALUE);

        addButton.setOnAction(e -> showAddTaskScreen());
        viewButton.setOnAction(e -> showViewTasksScreen());
        deleteButton.setOnAction(e -> showDeleteTaskScreen());
        clearButton.setOnAction(e -> showClearTasksScreen());
        exitButton.setOnAction(e -> primaryStage.close());

        VBox layout = new VBox(10, title, addButton, viewButton, deleteButton, clearButton, exitButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 350, 300);
        primaryStage.setScene(scene);
    }

    private void showAddTaskScreen() {
        Label title = new Label("Add Task");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField taskField = new TextField();
        taskField.setPromptText("Enter task");

        Label messageLabel = new Label();

        Button addButton = new Button("Add");
        Button backButton = new Button("Back");

        addButton.setOnAction(e -> {
            String task = taskField.getText().trim();
            if (task.isEmpty()) {
                messageLabel.setText("Task cannot be empty.");
            } else {
                todoList.addTask(task);
                messageLabel.setText("Task added.");
                taskField.clear();
            }
        });

        backButton.setOnAction(e -> showMainMenu());

        VBox layout = new VBox(10, title, taskField, addButton, backButton, messageLabel);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 350, 250);
        primaryStage.setScene(scene);
    }

    private void showViewTasksScreen() {
        Label title = new Label("View Tasks");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        ListView<String> listView = new ListView<>();
        refreshListView(listView);

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> showMainMenu());

        VBox layout = new VBox(10, title, listView, backButton);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setScene(scene);
    }

    private void showDeleteTaskScreen() {
        Label title = new Label("Delete Task");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        ListView<String> listView = new ListView<>();
        refreshListView(listView);

        Label messageLabel = new Label();

        Button deleteButton = new Button("Delete Selected");
        Button backButton = new Button("Back");

        deleteButton.setOnAction(e -> {
            int selectedIndex = listView.getSelectionModel().getSelectedIndex();

            if (selectedIndex < 0) {
                messageLabel.setText("Please select a task to delete.");
            } else {
                todoList.deleteTask(selectedIndex);
                refreshListView(listView);
                messageLabel.setText("Task deleted.");
            }
        });

        backButton.setOnAction(e -> showMainMenu());

        VBox layout = new VBox(10, title, listView, deleteButton, backButton, messageLabel);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        Scene scene = new Scene(layout, 400, 320);
        primaryStage.setScene(scene);
    }

    private void showClearTasksScreen() {
        Label title = new Label("Clear All Tasks?");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label messageLabel = new Label("Are you sure you want to remove all tasks?");

        Button yesButton = new Button("Yes");
        Button noButton = new Button("No");

        yesButton.setOnAction(e -> {
            todoList.clearTasks();
            showMainMenu();
        });

        noButton.setOnAction(e -> showMainMenu());

        VBox layout = new VBox(15, title, messageLabel, yesButton, noButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 350, 220);
        primaryStage.setScene(scene);
    }

    private void refreshListView(ListView<String> listView) {
        listView.getItems().clear();

        if (todoList.isEmpty()) {
            listView.getItems().add("No tasks found.");
        } else {
            for (int i = 0; i < todoList.size(); i++) {
                listView.getItems().add((i + 1) + ". " + todoList.getTasks().get(i));
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}